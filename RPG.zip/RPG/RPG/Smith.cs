﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPG
{
    abstract class Smith
    {
        public abstract Weapon CreateItem();
    }
}
