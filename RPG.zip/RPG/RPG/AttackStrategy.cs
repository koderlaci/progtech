﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPG
{
    abstract class AttackStrategy
    {
        public abstract void Attack(CharacterClass currentCharacter, CharacterClass target);
    }
}
