﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPG
{
    class Bowyer : Smith
    {
        public override Weapon CreateItem()
        {
            return new Bow();
        }
    }
}
