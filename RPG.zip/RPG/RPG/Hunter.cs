﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPG
{
    class Hunter : CharacterClass
    {
        AttackStrategy attackStrategy;

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        private string name;

        public int Health
        {
            get
            {
                return health;
            }
            set
            {
                health = value;
            }
        }
        private int health;

        public bool Alive
        {
            get
            {
                return alive;
            }
            set
            {
                alive = value;
            }
        }
        private bool alive;

        public Weapon Weapon
        {
            get
            {
                return weapon;
            }
            set
            {
                weapon = value;
            }
        }
        private Weapon weapon;

        public Hunter(string name, AttackStrategy attackStrategy, Weapon weapon)
        {
            this.name = name;
            this.attackStrategy = attackStrategy;
            this.health = 100;
            this.alive = true;
            this.weapon = weapon;
        }
        public void Attack(CharacterClass character)
        {
            if (this.alive)
            {
                attackStrategy.Attack(this, character);
            }
            else
            {
                Console.WriteLine("You can't do that while dead.");
            }
        }

        public void TakeDamage(int weaponDamage)
        {
            if (this.alive)
            {
                this.health -= weaponDamage;
            }
            else
            {
                Console.WriteLine("The target is already dead.");
            }
        }
    }
}
