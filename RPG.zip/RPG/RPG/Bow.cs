﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPG
{
    class Bow : Weapon
    {
        public string Type
        {
            get
            {
                return type;
            }
            set
            {
                type = value;
            }
        }
        private string type;
        public int Damage
        {
            get
            {
                return damage;
            }
            set
            {
                damage = value;
            }
        }
        private int damage;

        public Bow()
        {
            this.type = "Wooden Bow";
            this.damage = 15;
        }
    }
}
