﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPG
{
    interface Weapon
    {
        public string Type
        {
            get;
            set;
        }
        public int Damage
        {
            get;
            set;
        }
    }
}
