﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPG
{
    class WeaponSmith : Smith
    {
        public override Weapon CreateItem()
        {
            return new Sword();
        }
    }
}
