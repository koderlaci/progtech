﻿using System;

namespace RPG
{
    class Program
    {
        static void Main(string[] args)
        {
            Smith weaponSmith = new WeaponSmith();
            Smith bowyer = new Bowyer();

            Weapon sword = weaponSmith.CreateItem();
            Weapon bow = bowyer.CreateItem();

            AttackStrategy meeleAttack = new MeeleAttackStrategy();
            AttackStrategy rangedAttack = new RangedAttackStrategy();

            Warrior warrior = new Warrior("Warrior", meeleAttack, sword);
            Hunter hunter = new Hunter("Hunter", rangedAttack, bow);

            Console.WriteLine("Starting: ");
            Console.WriteLine(warrior.Name + " HP: " + warrior.Health);
            Console.WriteLine(hunter.Name + " HP: " + hunter.Health);
            hunter.Attack(warrior);
            Console.WriteLine(warrior.Name + " HP: " + warrior.Health);
            Console.WriteLine(hunter.Name + " HP: " + hunter.Health);
            warrior.Attack(hunter);
            Console.WriteLine(warrior.Name + " HP: " + warrior.Health);
            Console.WriteLine(hunter.Name + " HP: " + hunter.Health);
            hunter.Attack(warrior);
            Console.WriteLine(warrior.Name + " HP: " + warrior.Health);
            Console.WriteLine(hunter.Name + " HP: " + hunter.Health);
            warrior.Attack(hunter);
            Console.WriteLine(warrior.Name + " HP: " + warrior.Health);
            Console.WriteLine(hunter.Name + " HP: " + hunter.Health);
            hunter.Attack(warrior);
            Console.WriteLine(warrior.Name + " HP: " + warrior.Health);
            Console.WriteLine(hunter.Name + " HP: " + hunter.Health);
            warrior.Attack(hunter);
            Console.WriteLine(warrior.Name + " HP: " + warrior.Health);
            Console.WriteLine(hunter.Name + " HP: " + hunter.Health);
            hunter.Attack(warrior);
            Console.WriteLine(warrior.Name + " HP: " + warrior.Health);
            Console.WriteLine(hunter.Name + " HP: " + hunter.Health);
            warrior.Attack(hunter);
            Console.WriteLine(warrior.Name + " HP: " + warrior.Health);
            Console.WriteLine(hunter.Name + " HP: " + hunter.Health);
            hunter.Attack(warrior);
            Console.WriteLine(warrior.Name + " HP: " + warrior.Health);
            Console.WriteLine(hunter.Name + " HP: " + hunter.Health);
            warrior.Attack(hunter);
            Console.WriteLine(warrior.Name + " HP: " + warrior.Health);
            Console.WriteLine(hunter.Name + " HP: " + hunter.Health);
            hunter.Attack(warrior);
            Console.WriteLine(warrior.Name + " HP: " + warrior.Health);
            Console.WriteLine(hunter.Name + " HP: " + hunter.Health);
            warrior.Attack(hunter);
            Console.WriteLine(warrior.Name + " HP: " + warrior.Health);
            Console.WriteLine(hunter.Name + " HP: " + hunter.Health);
        }
    }
}
