﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPG
{
    interface CharacterClass
    {
        public string Name
        {
            get;
            set;
        }

        public int Health
        {
            get;
            set;
        }

        public bool Alive
        {
            get;
            set;
        }

        public Weapon Weapon
        {
            get;
            set;
        }

        public void TakeDamage(int weaponDamage);

        public void Attack(CharacterClass character);
    }
}
