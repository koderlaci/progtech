﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPG
{
    class RangedAttackStrategy : AttackStrategy
    {
        public override void Attack(CharacterClass currentCharacter, CharacterClass target)
        {
            target.TakeDamage(currentCharacter.Weapon.Damage);
            if (target.Health <= 0)
            {
                target.Alive = false;
            }
            else
            {
                Console.WriteLine(currentCharacter.Name + " attacked " + target.Name + " with a(n) " + currentCharacter.Weapon.Type);
            }
        }
    }
}
