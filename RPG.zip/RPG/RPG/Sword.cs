﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPG
{
    class Sword : Weapon
    {
        public string Type
        {
            get
            {
                return type;
            }
            set
            {
                type = value;
            }
        }
        private string type;
        public int Damage
        {
            get
            {
                return damage;
            }
            set
            {
                damage = value;
            }
        }
        private int damage;

        public Sword()
        {
            this.type = "Iron Sword";
            this.damage = 20;
        }
    }
}
